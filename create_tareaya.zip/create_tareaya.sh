#!/usr/bin/env bash
set -e

echo "Creando carpeta TareaYa..."
rm -rf TareaYa
mkdir -p TareaYa/backend/src/routes TareaYa/backend/prisma TareaYa/frontend/src TareaYa/frontend/public

# --- BACKEND ---
cat > TareaYa/backend/package.json <<'JSON'
{
  "name": "tareaya-backend",
  "version": "0.1.0",
  "main": "dist/server.js",
  "scripts": {
    "dev": "ts-node-dev --respawn --transpile-only src/server.ts",
    "build": "tsc",
    "start": "node dist/server.js"
  }
}
JSON

cat > TareaYa/backend/tsconfig.json <<'JSON'
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "CommonJS",
    "outDir": "dist",
    "rootDir": "src",
    "strict": true,
    "esModuleInterop": true
  }
}
JSON

cat > TareaYa/backend/.env.example <<'ENV'
DATABASE_URL=postgresql://user:password@localhost:5432/tareaya
PORT=4000
JWT_SECRET=change_me
ENV

cat > TareaYa/backend/prisma/schema.prisma <<'PRISMA'
generator client {
  provider = "prisma-client-js"
}
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id        Int      @id @default(autoincrement())
  name      String
  phone     String   @unique
  role      String   @default("client")
  createdAt DateTime @default(now())
}

model Task {
  id        Int      @id @default(autoincrement())
  title     String
  createdAt DateTime @default(now())
}
PRISMA

cat > TareaYa/backend/src/config/db.ts <<'TS'
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
export default prisma;
TS

cat > TareaYa/backend/src/routes/providers.ts <<'TS'
import { Router } from 'express';
import prisma from '../config/db';
const router = Router();

router.get('/', async (_req, res) => {
  res.json({ message: 'providers endpoint' });
});

export default router;
TS

cat > TareaYa/backend/src/server.ts <<'TS'
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import providersRouter from './routes/providers';
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (_req, res) => res.send('TareaYa API running'));
app.use('/api/providers', providersRouter);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
TS

cat > TareaYa/backend/README.md <<'MD'
# Backend TareaYa (TypeScript + Prisma)

1. Copiar .env.example -> .env y ajustar DATABASE_URL.
2. npm install
3. npx prisma generate
4. npx prisma migrate dev --name init
5. npm run dev
MD

# --- FRONTEND (Vite + React) ---
cat > TareaYa/frontend/package.json <<'JSON'
{
  "name": "tareaya-frontend",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "vite": "^4.0.0",
    "@vitejs/plugin-react": "^3.0.0",
    "typescript": "^5.0.0"
  }
}
JSON

cat > TareaYa/frontend/index.html <<'HTML'
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TareaYa</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
HTML

cat > TareaYa/frontend/src/main.tsx <<'TSX'
import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles.css";

createRoot(document.getElementById("root")!).render(<App />);
TSX

cat > TareaYa/frontend/src/App.tsx <<'TSX'
export default function App() {
  return (
    <div style={{ fontFamily: "Inter, Arial, sans-serif", padding: 24 }}>
      <header style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <h1 style={{ color: "#1D4ED8", margin: 0 }}>TareaYa</h1>
      </header>
      <main>
        <h2>Bienvenido a TareaYa — Demo</h2>
        <p>Plataforma de microtrabajos locales (Medellín).</p>
      </main>
    </div>
  );
}
TSX

cat > TareaYa/frontend/src/styles.css <<'CSS'
body { margin:0; font-family: Inter, Arial, sans-serif; background: #ffffff; color: #1E293B; }
h1 { margin: 0; }
CSS

# --- render.yaml (auto-deploy config for Render) ---
cat > TareaYa/render.yaml <<'YAML'
services:
  - type: web
    name: tareaya-backend
    env: node
    branch: main
    dir: backend
    buildCommand: npm install && npx prisma generate && npm run build
    startCommand: npm start
    instanceType: starter
    envVars:
      - key: PORT
        value: "4000"
      - key: JWT_SECRET
        generator: secret

  - type: web
    name: tareaya-frontend
    env: node
    branch: main
    dir: frontend
    buildCommand: npm install && npm run build
    startCommand: npm run preview
    instanceType: starter
    envVars:
      - key: VITE_API_URL
        value: "https://tareaya-backend.onrender.com"

databases:
  - name: tareaya-db
    engine: postgresql
    plan: starter
YAML

echo "✅ Carpeta TareaYa creada correctamente."
